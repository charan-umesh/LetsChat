package com.example.letschat.Notifications;

public class MyResponse {

    public int success;
}
